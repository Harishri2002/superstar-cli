# superstar_cli/__main__.py

from .animation import run

def main():
    run()

if __name__ == "__main__":
    main()